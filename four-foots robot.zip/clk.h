/*
 * clk.h
 *
 *  Created on: 2021��9��17��
 *      Author: dwb
 */

#ifndef CLK_H_
#define CLK_H_
void clk_Init ();




#endif /* CLK_H_ */
